﻿namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConnectionString =
            @"Server=DESKTOP-EQUE007\SQLEXPRESS;Database=ProductShop;Integrated Security=True; TrustServerCertificate = true; Encrypt = False;";
    }
}
